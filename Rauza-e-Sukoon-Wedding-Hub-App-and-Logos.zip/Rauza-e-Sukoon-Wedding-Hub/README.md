# Rauza-e-Sukoon Wedding Hub

Android starter project with:
- Navy/black and blue/gold branding
- Photo and video picker shortcuts
- Call shortcuts for the two supplied admin numbers
- WhatsApp shortcuts for the two supplied admin numbers
- Local PIN-protected admin panel with Android device-ID binding after setup
- GitHub Actions workflow to build a debug APK

## Build the APK on GitHub (mobile-friendly)
1. Create/open a GitHub repository.
2. Upload all files/folders from this ZIP to the repository root (keep folder paths).
3. Ensure the workflow is at `.github/workflows/build-apk.yml`.
4. Push to `main`, or open **Actions → Build Rauza-e-Sukoon Wedding Hub APK → Run workflow**.
5. When successful, open the run and download the `Rauza-e-Sukoon-Wedding-Hub-APK` artifact. Unzip it to get the APK.

## Important limitations
- The included workflow expects a Gradle wrapper (`gradlew`, `gradlew.bat`, and `gradle/wrapper/gradle-wrapper.jar` / properties). Those wrapper files are not bundled here. Generate them once with Gradle (`gradle wrapper`) or add them from a trusted Android project before running the workflow.
- This is a starter app, not a complete cloud-backed publishing platform. Photo/video selection currently opens media from the phone; it does not upload/share it online.
- Admin PIN and device binding are stored locally. Without a trusted backend and owner-device enrollment, this is not strong security: someone installing the app for the first time on another phone could enroll that phone. Do not use it to protect sensitive data.
- WhatsApp links open the WhatsApp app or browser. The phone numbers are included as supplied; country code +91 is used.
- A release APK for distribution needs proper signing and testing.

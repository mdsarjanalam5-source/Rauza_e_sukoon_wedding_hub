package com.rauzasukoon.weddinghub

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val navy = Color.rgb(4, 13, 35)
    private val blue = Color.rgb(0, 145, 220)
    private val gold = Color.rgb(235, 184, 45)
    private val adminPrefs by lazy { getSharedPreferences("local_admin", MODE_PRIVATE) }
    private val phone1 = "7321805421"
    private val phone2 = "9279591849"
    private val pickMedia = 101
    private var mediaType = "photo"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun baseLayout(): LinearLayout {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(22, 28, 22, 24)
            setBackgroundColor(navy)
        }
        return outer
    }

    private fun title(text: String, size: Float, color: Int = Color.WHITE): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            setPadding(8, 10, 8, 10)
        }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(blue)
            setOnClickListener { action() }
        }

    private fun addButton(parent: LinearLayout, text: String, action: () -> Unit) {
        val b = button(text, action)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 7, 0, 7)
        parent.addView(b, lp)
    }

    private fun showHome() {
        val root = baseLayout()
        root.addView(title("☾  Rauza-e-Sukoon  ✦", 27f, gold))
        root.addView(title("WEDDING HUB", 19f, Color.WHITE))
        root.addView(title("Your memories • Your celebrations", 14f, Color.LTGRAY))
        root.addView(title("Photos & Videos", 21f, gold))
        addButton(root, "Open Photos") { mediaType = "photo"; openPicker("image/*") }
        addButton(root, "Open Videos") { mediaType = "video"; openPicker("video/*") }
        addButton(root, "Call Admin 1") { dial(phone1) }
        addButton(root, "Call Admin 2") { dial(phone2) }
        addButton(root, "WhatsApp Admin 1") { whatsapp(phone1) }
        addButton(root, "WhatsApp Admin 2") { whatsapp(phone2) }
        addButton(root, "Admin Panel") { openAdminGate() }
        root.addView(title("Admin access is stored locally on this device.", 12f, Color.LTGRAY))
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun openPicker(mime: String) {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = mime
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        try {
            startActivityForResult(Intent.createChooser(intent, if (mime.startsWith("image")) "Select photo" else "Select video"), pickMedia)
        } catch (_: Exception) {
            Toast.makeText(this, "No compatible gallery app found.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Android but supported for this simple starter app")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickMedia && resultCode == RESULT_OK) {
            data?.data?.let {
                val label = if (mediaType == "photo") "Photo selected" else "Video selected"
                AlertDialog.Builder(this).setTitle(label)
                    .setMessage("Selected item:\n$it\n\nThis starter app opens media from your phone. A shared online gallery requires cloud storage/backend setup.")
                    .setPositiveButton("OK", null).show()
            }
        }
    }

    private fun dial(number: String) {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
        startActivity(intent)
    }

    private fun whatsapp(number: String) {
        val digits = "91$number"
        val uri = Uri.parse("https://wa.me/$digits")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: Exception) {
            Toast.makeText(this, "Could not open WhatsApp or browser.", Toast.LENGTH_LONG).show()
        }
    }

    private fun deviceId(): String =
        Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown-device"

    private fun openAdminGate() {
        val savedDevice = adminPrefs.getString("device_id", null)
        if (savedDevice != null && savedDevice != deviceId()) {
            Toast.makeText(this, "Admin panel is locked to the enrolled phone.", Toast.LENGTH_LONG).show()
            return
        }
        val hasPin = adminPrefs.getString("pin", null) != null
        val field = EditText(this).apply {
            hint = if (hasPin) "Enter admin PIN" else "Create admin PIN (6+ characters)"
            inputType = 0x00000081
        }
        AlertDialog.Builder(this)
            .setTitle(if (hasPin) "Admin Login" else "Set Up Admin on This Phone")
            .setMessage(if (hasPin) "Enter your local admin PIN." else "Create a PIN on this phone. Do not share it.")
            .setView(field)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Continue") { _, _ ->
                val value = field.text.toString()
                if (hasPin) {
                    if (value == adminPrefs.getString("pin", null)) showAdminPanel()
                    else Toast.makeText(this, "Incorrect PIN.", Toast.LENGTH_SHORT).show()
                } else if (value.length >= 6) {
                    adminPrefs.edit().putString("pin", value).putString("device_id", deviceId()).apply()
                    Toast.makeText(this, "Admin set up on this phone.", Toast.LENGTH_LONG).show()
                    showAdminPanel()
                } else {
                    Toast.makeText(this, "Use at least 6 characters.", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun showAdminPanel() {
        val root = baseLayout()
        root.addView(title("Admin Panel", 27f, gold))
        root.addView(title("Rauza-e-Sukoon Wedding Hub", 17f))
        root.addView(title("Local starter panel", 13f, Color.LTGRAY))
        addButton(root, "Choose photos for review") { mediaType = "photo"; openPicker("image/*") }
        addButton(root, "Choose videos for review") { mediaType = "video"; openPicker("video/*") }
        addButton(root, "Change Admin PIN") { changePin() }
        addButton(root, "Lock Admin Panel") { showHome() }
        root.addView(title("Note: media is selected from this phone; this version does not publish it to other users.", 12f, Color.LTGRAY))
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun changePin() {
        val field = EditText(this).apply {
            hint = "New PIN (6+ characters)"
            inputType = 0x00000081
        }
        AlertDialog.Builder(this).setTitle("Change Admin PIN").setView(field)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val pin = field.text.toString()
                if (pin.length >= 6) {
                    adminPrefs.edit().putString("pin", pin).apply()
                    Toast.makeText(this, "PIN updated on this phone.", Toast.LENGTH_SHORT).show()
                } else Toast.makeText(this, "Use at least 6 characters.", Toast.LENGTH_LONG).show()
            }.show()
    }
}
